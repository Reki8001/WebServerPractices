package es.cdmfp.dwes.ud1;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalTime;

@Controller
public class PrecioController {

    @GetMapping("/pedir")
    public String pedir(Model pedido)  {
        pedido.addAttribute("producto", "Camiseta Power Rangers Ultra Instinto 4K Full HD");
        pedido.addAttribute("precio", "20");
        pedido.addAttribute("referencia", "Agapito");

        return "saludo";
    }
}
